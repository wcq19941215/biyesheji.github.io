#include "type.h"
#include "stdio.h"

int main(int argc, char * argv[])
{
	printf("/\n");
	return 0;
}
